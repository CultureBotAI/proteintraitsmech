SELECT DISTINCT res1.ProteinID, res1.ResidueNumber, res2.ResidueNumber, res3.ResidueNumber

FROM Residue res1, Residue res2, Residue res3, 

Atom a1, Atom a2, AtomOfHBond aohb1, AtomOfHBond aohb2

WHERE res2.ProteinID = res1.ProteinID

AND res3.ProteinID = res1.ProteinID

AND res2.ResidueNumber = res1.ResidueNumber + 1

AND res3.ResidueNumber = res1.ResidueNumber + 2

AND res1.AminoAcid = "S"

AND ( ( (res1.Chi1-120) > 20 AND (res1.Chi1-120) < 140 )

OR ( (res1.Chi1+240) > 20 AND (res1.Chi1+240) < 140 ) )

AND ( ( (res1.Psi+120) > -180 AND (res1.Psi+120) < -80 )

OR ( (res1.Psi-240) > -180 AND (res1.Psi-240) < -80 ) )

AND res2.Phi > -140 AND res2.Phi < -20

AND res2.Psi > -90 AND res2.Psi < 40

AND res1.ResidueNumber = a1.ResidueNumber

AND res3.residueNumber = a2.ResidueNumber

AND res1.ProteinID = a1.ProteinID

AND a1.ProteinID = a2.ProteinID

AND a1.AtomName = "OG"

AND a2.AtomName = "N"

AND aohb1.AtomNumber = a1.AtomNumber

AND aohb2.AtomNumber = a2.AtomNumber

AND aohb1.ProteinID = res1.ProteinID

AND aohb2.ProteinID = res1.ProteinID

AND aohb1.HBondID = aohb2.HBondID