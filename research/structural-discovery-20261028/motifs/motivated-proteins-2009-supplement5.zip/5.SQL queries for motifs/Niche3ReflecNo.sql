SELECT DISTINCT res1.ProteinID, res1.ResidueNumber, res2.ResidueNumber, res3.ResidueNumber

FROM Residue res1, Residue res2, Residue res3

WHERE res2.ProteinID = res1.ProteinID

AND res3.ProteinID = res1.ProteinID

AND res2.Phi > -130 AND res2.Phi < -40

AND res2.Psi > -50 AND res2.Psi < 40

AND res3.Phi > -110 AND res3.Phi < -30

AND res3.Psi > 90 AND res3.Psi < 180

AND res2.ResidueNumber = res1.ResidueNumber + 1

AND res3.ResidueNumber = res1.ResidueNumber + 2