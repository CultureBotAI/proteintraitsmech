SELECT DISTINCT res1.ProteinID,

res1.ResidueNumber, res2.ResidueNumber, res3.ResidueNumber, res4.ResidueNumber

FROM Residue res1, Residue res2, Residue res3, Residue res4

WHERE res2.ProteinID = res1.ProteinID

AND res3.ProteinID = res1.ProteinID

AND res4.ProteinID = res1.ProteinID

AND res2.Phi > -120 AND res2.Phi < -30

AND res2.Psi > -60 AND res2.Psi < 30

AND res3.Phi > -140 AND res3.Phi < -50

AND res3.Psi > -50 AND res3.Psi < 40

AND res4.Phi > -160 AND res4.Phi < -30

AND res4.Psi > 90 AND res4.Psi < 180

AND res2.ResidueNumber = res1.ResidueNumber + 1

AND res3.ResidueNumber = res1.ResidueNumber + 2

AND res4.ResidueNumber = res1.ResidueNumber + 3