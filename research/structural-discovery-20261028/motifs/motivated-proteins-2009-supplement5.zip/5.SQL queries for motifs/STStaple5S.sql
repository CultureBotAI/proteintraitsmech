SELECT DISTINCT res1.ProteinID, res1.ResidueNumber, res2.ResidueNumber,

res3.ResidueNumber, res4.ResidueNumber, res5.ResidueNumber

FROM Residue res1, Residue res2, Residue res3, Residue res4, Residue res5,

Atom a1, Atom a2, AtomOfHBond aohb1, AtomOfHBond aohb2

WHERE res1.AminoAcid = "S"

AND res2.ProteinID = res1.ProteinID

AND res3.ProteinID = res1.ProteinID

AND res4.ProteinID = res1.ProteinID

AND res5.ProteinID = res1.ProteinID

AND res2.ResidueNumber = res1.ResidueNumber - 1

AND res3.ResidueNumber = res1.ResidueNumber - 2

AND res4.ResidueNumber = res1.ResidueNumber - 3

AND res5.ResidueNumber = res1.ResidueNumber - 4

AND res2.phi < 0 AND res3.phi < 0 AND res4.phi < 0

AND res1.ProteinID = a1.ProteinID

AND res1.ProteinID = a2.ProteinID

AND res1.ResidueNumber = a1.ResidueNumber

AND res5.ResidueNumber = a2.ResidueNumber

AND a1.AtomName = "OG"

AND a2.AtomName = "O"

AND aohb1.ProteinID = res1.ProteinID

AND aohb2.ProteinID = res1.ProteinID

AND a1.AtomNumber = aohb1.AtomNumber

AND a2.AtomNumber = aohb2.AtomNumber

AND aohb1.HBondID = aohb2.HBondID