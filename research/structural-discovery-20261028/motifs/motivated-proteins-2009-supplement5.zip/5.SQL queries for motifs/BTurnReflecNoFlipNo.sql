SELECT DISTINCT res1.ProteinID, 

res1.ResidueNumber, res2.ResidueNumber, res3.ResidueNumber, res4.ResidueNumber

FROM Residue res1, Residue res2, Residue res3, Residue res4, 

Atom a1, Atom a2, AtomOfHBond aohb1, AtomOfHBond aohb2

WHERE res2.ProteinID = res1.ProteinID

AND res3.ProteinID = res1.ProteinID

AND res4.ProteinID = res1.ProteinID

AND res2.ResidueNumber = res1.ResidueNumber + 1

AND res3.ResidueNumber = res1.ResidueNumber + 2

AND res4.ResidueNumber = res1.ResidueNumber + 3

AND res2.Phi > -140 AND res2.Phi < -20

AND res2.Psi > -90 AND res2.Psi < 40 

AND res3.Phi > -140 AND res3.Phi < -20 

AND res3.Psi > -90 AND res3.Psi < 40

AND res1.ProteinID = a1.ProteinID

AND res1.ProteinID = a2.ProteinID

AND res1.ResidueNumber = a1.ResidueNumber

AND res4.ResidueNumber = a2.ResidueNumber

AND a1.AtomName = "O" AND a2.AtomName = "N"

AND a1.AtomNumber = aohb1.AtomNumber

AND a2.AtomNumber = aohb2.AtomNumber

AND aohb1.ProteinID = res1.ProteinID

AND aohb2.ProteinID = res1.ProteinID

AND aohb1.HBondID = aohb2.HBondID