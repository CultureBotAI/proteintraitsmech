SELECT DISTINCT res1.ProteinID, res1.ResidueNumber, res2.ResidueNumber, 

res3.ResidueNumber, res4.ResidueNumber, res5.ResidueNumber

FROM Residue res1, Residue res2, Residue res3, Residue res4, Residue res5,

Atom a1, Atom a2, Atom a3, 

AtomOfHBond aohb1, AtomOfHBond aohb2, AtomOfHBond aohb3, AtomOfHBond aohb4

WHERE res2.ProteinID = res1.ProteinID

AND res3.ProteinID = res1.ProteinID

AND res4.ProteinID = res1.ProteinID

AND res5.ProteinID = res1.ProteinID

AND res2.ResidueNumber = res1.ResidueNumber + 1

AND res3.ResidueNumber = res1.ResidueNumber + 2

AND res4.ResidueNumber = res1.ResidueNumber + 3

AND res5.ResidueNumber = res1.ResidueNumber + 4

AND res2.phi < 0 AND res3.phi < 0 AND res4.phi < 0

AND res1.ProteinID = a1.ProteinID

AND res1.ProteinID = a2.ProteinID

AND res1.ProteinID = a3.ProteinID

AND res1.ResidueNumber = a1.ResidueNumber

AND res4.residueNumber = a2.ResidueNumber

AND res5.ResidueNumber = a3.ResidueNumber

AND a1.AtomName = "O" AND a2.AtomName = "N"

AND a3.AtomName = "N"

AND aohb1.ProteinID = res1.ProteinID

AND aohb2.ProteinID = res1.ProteinID

AND aohb3.ProteinID = res1.ProteinID

AND aohb4.ProteinID = res1.ProteinID

AND a1.AtomNumber = aohb1.AtomNumber

AND a2.AtomNumber = aohb2.AtomNumber

AND a1.AtomNumber = aohb3.AtomNumber

AND a3.AtomNumber = aohb4.AtomNumber

AND aohb1.HBondID = aohb2.HBondID

AND aohb3.HBondID = aohb4.HBondID