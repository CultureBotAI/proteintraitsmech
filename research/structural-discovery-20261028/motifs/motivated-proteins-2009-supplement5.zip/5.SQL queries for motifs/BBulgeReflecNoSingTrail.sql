SELECT DISTINCT res1.ProteinID, res1.ResidueNumber, res2.ResidueNumber, res3.ResidueNumber

FROM Residue res1, Residue res2, Residue res3, 

Atom a1, Atom a2, Atom a3, Atom a4, 

AtomOfHBond aohb1, AtomOfHBond aohb2, AtomOfHBond aohb3, AtomOfHBond aohb4

WHERE res2.ProteinID = res1.ProteinID

AND res3.ProteinID = res1.ProteinID

AND res2.ResidueNumber = res1.ResidueNumber + 1

AND res3.ResidueNumber > res1.ResidueNumber + 4

AND res1.Phi > -140 AND res1.Phi < -20

AND res1.Psi > -90 AND res1.Psi < 40

AND ( ( res2.Phi > -180 AND res2.Phi < -25 ) OR ( res2.Phi > 150 AND res2.Phi < 180 ) )

AND ( ( res2.Psi > 40 AND res2.Psi < 180 ) OR ( res2.Psi > -180 AND res2.Psi < -150 ) )

AND res1.ProteinID = a1.ProteinID

AND res1.ProteinID = a2.ProteinID

AND res1.ProteinID = a3.ProteinID

AND res1.ProteinID = a4.ProteinID

AND res1.ResidueNumber = a1.ResidueNumber

AND res2.ResidueNumber = a3.ResidueNumber

AND res3.ResidueNumber = a2.ResidueNumber

AND res3.ResidueNumber = a4.ResidueNumber

AND a1.AtomName = "N" AND a2.AtomName = "O"

AND a3.AtomName = "O" AND a4.AtomName = "N"

AND aohb1.ProteinID = res1.ProteinID

AND aohb2.ProteinID = res1.ProteinID

AND aohb3.ProteinID = res1.ProteinID

AND aohb4.ProteinID = res1.ProteinID

AND a1.AtomNumber = aohb1.AtomNumber

AND a2.AtomNumber = aohb2.AtomNumber

AND a3.AtomNumber = aohb3.AtomNUmber

AND a4.AtomNumber = aohb4.AtomNumber

AND aohb1.HBondID = aohb2.HBondID

AND aohb3.HBondID = aohb4.HBondID